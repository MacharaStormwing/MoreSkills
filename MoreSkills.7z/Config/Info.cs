﻿namespace MoreSkills.Info
{
    public static class PluginInfo
    {
        public const string Name = "MoreSkills";

        public const string Guid = "com.guiriguy.moreskills";

        public const string Version = "0.20.1";
    }
}
